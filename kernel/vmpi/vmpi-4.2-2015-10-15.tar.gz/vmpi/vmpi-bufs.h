#ifndef __VMPI_BUFS_H__
#define __VMPI_BUFS_H__

#include <linux/uio.h>
#include <linux/list.h>


struct vmpi_rawbuf {
    size_t size;
    atomic_t refcnt;
    uint8_t buf[0];
};

struct vmpi_buf {
    struct vmpi_rawbuf  *raw;
    size_t              len;

    struct list_head    node;
};

struct vmpi_buf *vmpi_buf_alloc(size_t size, size_t unused, gfp_t gfp);

struct vmpi_buf * vmpi_buf_clone(struct vmpi_buf *vb, gfp_t gfp);

void vmpi_buf_free(struct vmpi_buf *vb);

static inline uint8_t *vmpi_buf_data(struct vmpi_buf *vb)
{
        return vb->raw->buf;
}

static inline size_t vmpi_buf_size(struct vmpi_buf *vb)
{
        return vb->raw->size;
}

static inline size_t vmpi_buf_len(struct vmpi_buf *vb)
{
        return vb->len;
}

static inline void vmpi_buf_set_len(struct vmpi_buf *vb, size_t len)
{
        vb->len = len;
}

#endif /* __VMPI_BUFS_H__ */
