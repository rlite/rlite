#include <linux/module.h>
#include <linux/types.h>
#include <linux/slab.h>
#include "vmpi-bufs.h"


struct vmpi_buf *
vmpi_buf_alloc(size_t size, size_t unused, gfp_t gfp)
{
        struct vmpi_buf *rb;
        uint8_t *kbuf;

        rb = kmalloc(sizeof(*rb), gfp);
        if (unlikely(!rb)) {
                printk("Out of memory\n");
                return NULL;
        }

        kbuf = kmalloc(sizeof(*rb->raw) + size, gfp);
        if (unlikely(!kbuf)) {
                kfree(rb);
                printk("Out of memory\n");
                return NULL;
        }

        rb->raw = (struct vmpi_rawbuf *)kbuf;
        rb->raw->size = size;
        atomic_set(&rb->raw->refcnt, 1);
        rb->len = size;

        return rb;
}
EXPORT_SYMBOL_GPL(vmpi_buf_alloc);

void
vmpi_buf_free(struct vmpi_buf *rb)
{
        if (atomic_dec_and_test(&rb->raw->refcnt)) {
                kfree(rb->raw);
        }
        kfree(rb);
}
EXPORT_SYMBOL_GPL(vmpi_buf_free);

MODULE_LICENSE("GPL");
