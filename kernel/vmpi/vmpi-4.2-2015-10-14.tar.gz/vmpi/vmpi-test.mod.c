#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x6455f54, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0xdaa92abb, __VMLINUX_SYMBOL_STR(param_ops_uint) },
	{ 0x72890bd3, __VMLINUX_SYMBOL_STR(noop_llseek) },
	{ 0x80989da0, __VMLINUX_SYMBOL_STR(misc_deregister) },
	{ 0xfae05454, __VMLINUX_SYMBOL_STR(misc_register) },
	{ 0x707857c6, __VMLINUX_SYMBOL_STR(copy_to_iter) },
	{ 0xdb7305a1, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0x1000e51, __VMLINUX_SYMBOL_STR(schedule) },
	{ 0x8526c35a, __VMLINUX_SYMBOL_STR(remove_wait_queue) },
	{ 0xc9fef317, __VMLINUX_SYMBOL_STR(add_wait_queue) },
	{ 0x24f6ae38, __VMLINUX_SYMBOL_STR(copy_from_iter) },
	{ 0xe362e5c1, __VMLINUX_SYMBOL_STR(vmpi_buf_alloc) },
	{ 0xffd5a395, __VMLINUX_SYMBOL_STR(default_wake_function) },
	{ 0x97bb6e16, __VMLINUX_SYMBOL_STR(current_task) },
	{ 0x9e88526, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0x7b045dac, __VMLINUX_SYMBOL_STR(vmpi_provider_find_instance) },
	{ 0xf5d6f962, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0xe4e0622b, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0xdae80100, __VMLINUX_SYMBOL_STR(_raw_spin_unlock) },
	{ 0xe259ae9e, __VMLINUX_SYMBOL_STR(_raw_spin_lock) },
	{ 0xa6bbd805, __VMLINUX_SYMBOL_STR(__wake_up) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0xe8d06cf4, __VMLINUX_SYMBOL_STR(vmpi_buf_free) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=vmpi-bufs,vmpi-provider";

