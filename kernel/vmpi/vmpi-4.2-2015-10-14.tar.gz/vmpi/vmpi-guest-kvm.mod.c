#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x6455f54, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0x2d3385d3, __VMLINUX_SYMBOL_STR(system_wq) },
	{ 0xe4e0622b, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0xc897c382, __VMLINUX_SYMBOL_STR(sg_init_table) },
	{ 0xe1e12065, __VMLINUX_SYMBOL_STR(single_open) },
	{ 0x50c7d0f8, __VMLINUX_SYMBOL_STR(single_release) },
	{ 0x1b9ad1b1, __VMLINUX_SYMBOL_STR(virtqueue_enable_cb_delayed) },
	{ 0xd9d3bcd3, __VMLINUX_SYMBOL_STR(_raw_spin_lock_bh) },
	{ 0xe8d06cf4, __VMLINUX_SYMBOL_STR(vmpi_buf_free) },
	{ 0xd1f58462, __VMLINUX_SYMBOL_STR(seq_printf) },
	{ 0x88bfa7e, __VMLINUX_SYMBOL_STR(cancel_work_sync) },
	{ 0x558dee29, __VMLINUX_SYMBOL_STR(remove_proc_entry) },
	{ 0x86d0a11d, __VMLINUX_SYMBOL_STR(virtqueue_add_inbuf) },
	{ 0xb4f0243e, __VMLINUX_SYMBOL_STR(mutex_unlock) },
	{ 0x34aa0ec0, __VMLINUX_SYMBOL_STR(virtqueue_kick) },
	{ 0x91715312, __VMLINUX_SYMBOL_STR(sprintf) },
	{ 0x950ca83f, __VMLINUX_SYMBOL_STR(seq_read) },
	{ 0xc798dec3, __VMLINUX_SYMBOL_STR(virtqueue_add_outbuf) },
	{ 0xac0500c4, __VMLINUX_SYMBOL_STR(virtqueue_get_buf) },
	{ 0x69436492, __VMLINUX_SYMBOL_STR(__mutex_init) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x4c9d28b0, __VMLINUX_SYMBOL_STR(phys_base) },
	{ 0x129201ad, __VMLINUX_SYMBOL_STR(virtqueue_disable_cb) },
	{ 0xc23bebb2, __VMLINUX_SYMBOL_STR(mutex_lock) },
	{ 0xe362e5c1, __VMLINUX_SYMBOL_STR(vmpi_buf_alloc) },
	{ 0x6784b211, __VMLINUX_SYMBOL_STR(unregister_virtio_driver) },
	{ 0xbba70a2d, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_bh) },
	{ 0xdb7305a1, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0x1dcc4a45, __VMLINUX_SYMBOL_STR(vmpi_provider_register) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
	{ 0xf5d6f962, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0x2568bce9, __VMLINUX_SYMBOL_STR(proc_create_data) },
	{ 0xef9b791f, __VMLINUX_SYMBOL_STR(seq_lseek) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x69acdf38, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0xf0f7f27c, __VMLINUX_SYMBOL_STR(vmpi_provider_unregister) },
	{ 0x2e0d2f7f, __VMLINUX_SYMBOL_STR(queue_work_on) },
	{ 0xb57d5e26, __VMLINUX_SYMBOL_STR(virtqueue_detach_unused_buf) },
	{ 0x98599249, __VMLINUX_SYMBOL_STR(virtqueue_enable_cb) },
	{ 0x84c78cef, __VMLINUX_SYMBOL_STR(register_virtio_driver) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=virtio_ring,vmpi-bufs,virtio,vmpi-provider";

MODULE_ALIAS("virtio:d0000000Fv*");
