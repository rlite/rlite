#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x6455f54, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0xe4e0622b, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0xd6ee688f, __VMLINUX_SYMBOL_STR(vmalloc) },
	{ 0xe1e12065, __VMLINUX_SYMBOL_STR(single_open) },
	{ 0x7aa1756e, __VMLINUX_SYMBOL_STR(kvfree) },
	{ 0xdf0f75c6, __VMLINUX_SYMBOL_STR(eventfd_signal) },
	{ 0x9e607da9, __VMLINUX_SYMBOL_STR(vhost_dev_check_owner) },
	{ 0x50c7d0f8, __VMLINUX_SYMBOL_STR(single_release) },
	{ 0x84cf2d5b, __VMLINUX_SYMBOL_STR(vhost_init_used) },
	{ 0xd9d3bcd3, __VMLINUX_SYMBOL_STR(_raw_spin_lock_bh) },
	{ 0x34dcbf08, __VMLINUX_SYMBOL_STR(vhost_poll_start) },
	{ 0xe8d06cf4, __VMLINUX_SYMBOL_STR(vmpi_buf_free) },
	{ 0xd1f58462, __VMLINUX_SYMBOL_STR(seq_printf) },
	{ 0x558dee29, __VMLINUX_SYMBOL_STR(remove_proc_entry) },
	{ 0x44b1d426, __VMLINUX_SYMBOL_STR(__dynamic_pr_debug) },
	{ 0xb4f0243e, __VMLINUX_SYMBOL_STR(mutex_unlock) },
	{ 0xf7b03e11, __VMLINUX_SYMBOL_STR(vhost_dev_cleanup) },
	{ 0x511eb181, __VMLINUX_SYMBOL_STR(vhost_log_access_ok) },
	{ 0x950ca83f, __VMLINUX_SYMBOL_STR(seq_read) },
	{ 0x1e25071c, __VMLINUX_SYMBOL_STR(vhost_enable_notify) },
	{ 0x9e88526, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0x8a63e900, __VMLINUX_SYMBOL_STR(vhost_dev_has_owner) },
	{ 0xf12ed9b8, __VMLINUX_SYMBOL_STR(vhost_poll_flush) },
	{ 0x4f8b5ddb, __VMLINUX_SYMBOL_STR(_copy_to_user) },
	{ 0xbbd946dc, __VMLINUX_SYMBOL_STR(vhost_disable_notify) },
	{ 0xfae05454, __VMLINUX_SYMBOL_STR(misc_register) },
	{ 0xc414c4c0, __VMLINUX_SYMBOL_STR(vhost_dev_ioctl) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x8bdb352f, __VMLINUX_SYMBOL_STR(vhost_log_write) },
	{ 0xc23bebb2, __VMLINUX_SYMBOL_STR(mutex_lock) },
	{ 0x7b9cb443, __VMLINUX_SYMBOL_STR(vhost_get_vq_desc) },
	{ 0x72890bd3, __VMLINUX_SYMBOL_STR(noop_llseek) },
	{ 0xe362e5c1, __VMLINUX_SYMBOL_STR(vmpi_buf_alloc) },
	{ 0xd01ca4a5, __VMLINUX_SYMBOL_STR(vhost_dev_set_owner) },
	{ 0x308e647f, __VMLINUX_SYMBOL_STR(vhost_add_used_and_signal_n) },
	{ 0x269f7a09, __VMLINUX_SYMBOL_STR(vhost_dev_reset_owner_prepare) },
	{ 0x4d9c601e, __VMLINUX_SYMBOL_STR(vhost_add_used_and_signal) },
	{ 0xec2e83e2, __VMLINUX_SYMBOL_STR(vhost_discard_vq_desc) },
	{ 0x73ce6a2c, __VMLINUX_SYMBOL_STR(vhost_poll_queue) },
	{ 0xbba70a2d, __VMLINUX_SYMBOL_STR(_raw_spin_unlock_bh) },
	{ 0xdb7305a1, __VMLINUX_SYMBOL_STR(__stack_chk_fail) },
	{ 0xa202a8e5, __VMLINUX_SYMBOL_STR(kmalloc_order_trace) },
	{ 0xc84c3996, __VMLINUX_SYMBOL_STR(vhost_poll_stop) },
	{ 0xf61d2853, __VMLINUX_SYMBOL_STR(vhost_poll_init) },
	{ 0x1dcc4a45, __VMLINUX_SYMBOL_STR(vmpi_provider_register) },
	{ 0xbdfb6dbb, __VMLINUX_SYMBOL_STR(__fentry__) },
	{ 0xf5d6f962, __VMLINUX_SYMBOL_STR(kmem_cache_alloc_trace) },
	{ 0xa6bbd805, __VMLINUX_SYMBOL_STR(__wake_up) },
	{ 0x2568bce9, __VMLINUX_SYMBOL_STR(proc_create_data) },
	{ 0xef9b791f, __VMLINUX_SYMBOL_STR(seq_lseek) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x69acdf38, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0xfbc1952a, __VMLINUX_SYMBOL_STR(vhost_dev_reset_owner) },
	{ 0xf0f7f27c, __VMLINUX_SYMBOL_STR(vmpi_provider_unregister) },
	{ 0xe255d884, __VMLINUX_SYMBOL_STR(vhost_dev_init) },
	{ 0x24e37cc4, __VMLINUX_SYMBOL_STR(vhost_dev_stop) },
	{ 0x6c66786, __VMLINUX_SYMBOL_STR(vhost_vq_access_ok) },
	{ 0x4f6b400b, __VMLINUX_SYMBOL_STR(_copy_from_user) },
	{ 0x68fdf73d, __VMLINUX_SYMBOL_STR(vhost_vring_ioctl) },
	{ 0x80989da0, __VMLINUX_SYMBOL_STR(misc_deregister) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=vhost,vmpi-bufs,vmpi-provider";


MODULE_INFO(srcversion, "CF1E4698D86CBFE96DDB4CD");
